import SwiftUI
import UIKit
import ImageIO

struct ProfileSelectionRemoteAnimatedImage: UIViewRepresentable {
    let urlString: String

    func makeUIView(context: Context) -> UIImageView {
        let view = UIImageView()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        view.backgroundColor = .clear
        view.isUserInteractionEnabled = false
        return view
    }

    func updateUIView(_ view: UIImageView, context: Context) {
        let requestedURL = urlString.trimmingCharacters(in: .whitespacesAndNewlines)

        guard requestedURL != context.coordinator.loadedURL else {
            return
        }

        context.coordinator.loadedURL = requestedURL
        view.stopAnimating()
        view.image = nil

        Task {
            let image = await Self.loadImage(requestedURL)

            await MainActor.run {
                guard context.coordinator.loadedURL == requestedURL else {
                    return
                }

                view.image = image

                if let image, image.images != nil, image.duration > 0 {
                    view.startAnimating()
                }
            }
        }
    }

    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    final class Coordinator {
        var loadedURL: String?
    }

    private static func loadImage(_ value: String) async -> UIImage? {
        guard value.count <= 2048 else { return nil }
        guard !value.contains(where: { $0.isWhitespace }) else { return nil }

        guard let url = URL(string: value),
              let scheme = url.scheme?.lowercased(),
              scheme == "http" || scheme == "https" else {
            return nil
        }

        do {
            let (data, response) = try await URLSession.shared.data(from: url)

            if let http = response as? HTTPURLResponse,
               !(200..<300).contains(http.statusCode) {
                return nil
            }

            guard let source = CGImageSourceCreateWithData(data as CFData, nil) else {
                return nil
            }

            let count = CGImageSourceGetCount(source)
            guard count > 0 else { return nil }

            if count == 1 {
                guard let cg = CGImageSourceCreateImageAtIndex(source, 0, nil) else {
                    return nil
                }
                return UIImage(cgImage: cg)
            }

            var frames: [UIImage] = []
            var duration: Double = 0

            for index in 0..<count {
                guard let cg = CGImageSourceCreateImageAtIndex(source, index, nil) else {
                    continue
                }

                frames.append(UIImage(cgImage: cg))

                if let properties =
                    CGImageSourceCopyPropertiesAtIndex(source, index, nil) as? [CFString: Any],
                   let gif =
                    properties[kCGImagePropertyGIFDictionary] as? [CFString: Any] {

                    let unclamped =
                        gif[kCGImagePropertyGIFUnclampedDelayTime] as? Double

                    let clamped =
                        gif[kCGImagePropertyGIFDelayTime] as? Double

                    duration += max(unclamped ?? clamped ?? 0.1, 0.02)
                } else {
                    duration += 0.1
                }
            }

            guard !frames.isEmpty else { return nil }

            return UIImage.animatedImage(
                with: frames,
                duration: max(duration, 0.1)
            )
        } catch {
            return nil
        }
    }
}
